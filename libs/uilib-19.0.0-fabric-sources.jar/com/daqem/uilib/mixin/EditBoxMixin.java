package com.daqem.uilib.mixin;

import com.daqem.uilib.UILib;
import com.daqem.uilib.api.widget.IEditBoxWidget;
import com.daqem.uilib.gui.widget.EditBoxWidget;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_342;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_342.class)
public abstract class EditBoxMixin extends class_339 implements IEditBoxWidget {

    @Shadow protected abstract void updateTextPosition();

    public EditBoxMixin(int x, int y, int width, int height, class_2561 message) {
        super(x, y, width, height, message);
    }

    @Override
    public void uilib$updateTextPosition() {
        updateTextPosition();
    }

    @Redirect(
            method = "renderWidget(Lnet/minecraft/client/gui/GuiGraphics;IIF)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gui/GuiGraphics;blitSprite(Lcom/mojang/blaze3d/pipeline/RenderPipeline;Lnet/minecraft/resources/Identifier;IIII)V"
            )
    )
    private void suppressBlitSprite(class_332 instance, RenderPipeline pipeline, class_2960 sprite, int x, int y, int width, int height) {
        if (((class_342) (Object) this) instanceof EditBoxWidget editBoxWidget) {
            if (editBoxWidget.hasInputValidationErrors()) {
                instance.method_52706(pipeline, UILib.getId("widget/text_field_error"), x, y, width, height);
                return;
            }
        }
        instance.method_52706(pipeline, sprite, x, y, width, height);
    }
}
