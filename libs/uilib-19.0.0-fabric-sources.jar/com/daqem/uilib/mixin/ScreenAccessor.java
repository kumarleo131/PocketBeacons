package com.daqem.uilib.mixin;

import com.daqem.uilib.api.screen.IScreenAccessor;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import java.util.List;
import net.minecraft.class_332;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_437;
import net.minecraft.class_6379;

@Mixin(class_437.class)
public abstract class ScreenAccessor implements IScreenAccessor {

    @Shadow
    @Final
    private List<class_4068> renderables;

    @Shadow
    @Final
    private List<class_364> children;

    @Shadow
    @Final
    private List<class_6379> narratables;

    @Shadow
    protected abstract void removeWidget(class_364 listener);

    @Shadow
    protected abstract void renderBlurredBackground(class_332 guiGraphics);

    @Shadow
    protected abstract void renderPanorama(class_332 guiGraphics, float partialTick);

    @Override
    public List<class_4068> uilib$getRenderables() {
        return this.renderables;
    }

    @Override
    public List<class_364> uilib$getChildren() {
        return this.children;
    }

    @Override
    public List<class_6379> uilib$getNarratables() {
        return this.narratables;
    }

    @Override
    public void uilib$removeWidget(class_364 widget) {
        this.removeWidget(widget);
    }

    @Override
    public void uilib$renderBlurredBackground(class_332 guiGraphics) {
        this.renderBlurredBackground(guiGraphics);
    }

    @Override
    public void uilib$renderPanoramaBackground(class_332 guiGraphics, float partialTicks) {
        this.renderPanorama(guiGraphics, partialTicks);
    }
}
