package com.daqem.uilib.mixin;

import net.minecraft.class_7528;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_7528.class)
public interface AbstractScrollAreaAccessor {

    @Accessor("scrolling")
    boolean uilib$isScrolling();
}
