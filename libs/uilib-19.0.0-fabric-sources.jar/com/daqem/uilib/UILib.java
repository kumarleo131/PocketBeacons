package com.daqem.uilib;


import com.mojang.logging.LogUtils;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5250;
import org.slf4j.Logger;

public class UILib {

    public static final Logger LOGGER = LogUtils.getLogger();
    public static final String MOD_ID = "uilib";

    public static class_5250 translatable(String resourceKey) {
        return class_2561.method_43471(MOD_ID + "." + resourceKey);
    }

    public static class_5250 translatable(String resourceKey, Object... args) {
        return class_2561.method_43469(MOD_ID + "." + resourceKey, args);
    }

    public static class_2960 getId(String location) {
        return class_2960.method_60655(MOD_ID, location);
    }
}
