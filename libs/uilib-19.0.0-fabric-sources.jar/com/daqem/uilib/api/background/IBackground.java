package com.daqem.uilib.api.background;

import net.minecraft.class_4068;

public interface IBackground extends class_4068 {
}
