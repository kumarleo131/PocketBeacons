package com.daqem.uilib.api.widget.skilltree;

import com.daqem.uilib.api.skilltree.ISkillTreeItem;
import com.daqem.uilib.api.widget.IWidget;
import net.minecraft.class_332;

public interface ISkillTreeItemWidget extends IWidget {

    void renderTooltips(class_332 guiGraphics, int mouseX, int mouseY);

    ISkillTreeItem getSkillTreeItem();
}
