package com.daqem.uilib.api.widget;

import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_6379;
import net.minecraft.class_8021;
import net.minecraft.class_8030;
import org.jetbrains.annotations.NotNull;

public interface IWidget extends class_4068, class_364, class_8021, class_6379 {

    @Override
    default @NotNull class_8030 method_48202() {
        return class_8021.super.method_48202();
    }

    /*
     * This has been implemented in the AbstractWidgetMixin.
     * Adding default methods here to avoid compilation errors because you should add IWidget to your widget class.
     */
    default int uilib$getParentX() {
        return 0;
    }
    default int uilib$getParentY() {
        return 0;
    }
    default void uilib$updateParentPosition(int parentX, int parentY) {
    }
}
