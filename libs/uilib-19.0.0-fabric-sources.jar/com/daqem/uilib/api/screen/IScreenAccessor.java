package com.daqem.uilib.api.screen;

import java.util.List;
import net.minecraft.class_332;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_6379;

public interface IScreenAccessor {

    List<class_4068> uilib$getRenderables();

    List<class_364> uilib$getChildren();

    List<class_6379> uilib$getNarratables();

    void uilib$removeWidget(class_364 widget);

    void uilib$renderBlurredBackground(class_332 guiGraphics);

    void uilib$renderPanoramaBackground(class_332 guiGraphics, float partialTicks);
}
