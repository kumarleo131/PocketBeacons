package com.daqem.uilib.api;

import net.minecraft.class_332;
import net.minecraft.class_4068;
import net.minecraft.class_8021;

public interface IRenderable extends class_4068, class_8021 {

    void render(class_332 guiGraphics, int mouseX, int mouseY, float partialTick, int parentWidth, int parentHeight);
    void renderBase(class_332 guiGraphics, int mouseX, int mouseY, float partialTick, int parentWidth, int parentHeight);

}
