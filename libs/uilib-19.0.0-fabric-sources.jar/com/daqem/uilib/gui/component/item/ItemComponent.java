package com.daqem.uilib.gui.component.item;

import com.daqem.uilib.gui.component.AbstractComponent;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_332;

public class ItemComponent extends AbstractComponent {

    private class_1799 itemStack;
    private boolean decorated;

    public ItemComponent(class_1799 itemStack) {
        this(0, 0, itemStack);
    }

    public ItemComponent(int x, int y, class_1799 itemStack) {
        this(x, y, itemStack, false);
    }

    public ItemComponent(int x, int y, class_1799 itemStack, boolean decorated) {
        super(x, y, 16, 16);

        if (itemStack == null) {
            throw new IllegalArgumentException("ItemStack cannot be null");
        }

        this.itemStack = itemStack;
        this.decorated = decorated;
    }

    public class_1799 getItemStack() {
        return itemStack;
    }

    public void setItemStack(class_1799 itemStack) {
        this.itemStack = itemStack;
    }

    public boolean isDecorated() {
        return decorated;
    }

    public void setDecorated(boolean decorated) {
        this.decorated = decorated;
    }

    @Override
    public void render(class_332 guiGraphics, int mouseX, int mouseY, float partialTick, int parentWidth, int parentHeight) {
        guiGraphics.method_51445(
                getItemStack(),
                getTotalX(),
                getTotalY()
        );
        if (isDecorated()) {
            guiGraphics.method_51431(
                    class_310.method_1551().field_1772,
                    getItemStack(),
                    getTotalX(),
                    getTotalY()
            );
        }
    }
}
