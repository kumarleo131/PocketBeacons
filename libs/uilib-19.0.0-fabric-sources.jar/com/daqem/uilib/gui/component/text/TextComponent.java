package com.daqem.uilib.gui.component.text;

import net.minecraft.class_2561;
import net.minecraft.class_332;

public class TextComponent extends AbstractSingleLineTextComponent {

    public TextComponent(int x, int y, class_2561 text) {
        super(x, y, text);
    }

    public TextComponent(int x, int y, class_2561 text, int color) {
        super(x, y, text, color);
    }

    @Override
    public void render(class_332 guiGraphics, int mouseX, int mouseY, float partialTick, int parentWidth, int parentHeight) {
        guiGraphics.method_51439(
                this.getFont(),
                this.getText(),
                this.getTotalX(),
                this.getTotalY(),
                this.getColor(),
                this.isDrawShadow()
        );
    }
}
