package com.daqem.uilib.gui.component.text;

import net.minecraft.class_2561;
import net.minecraft.class_327;

public abstract class AbstractSingleLineTextComponent extends AbstractTextComponent {

    public AbstractSingleLineTextComponent(int x, int y, class_2561 text) {
        super(x, y, 0, 0, text);
        updateSize();
    }

    public AbstractSingleLineTextComponent(int x, int y, class_2561 text, int color) {
        super(x, y, 0, 0, text, color);
        updateSize();
    }

    @Override
    public void setFont(class_327 font) {
        super.setFont(font);
        updateSize();
    }

    @Override
    public void setText(class_2561 text) {
        super.setText(text);
        updateSize();
    }

    protected void updateSize() {
        setWidth(getFont().method_27525(getText()));
        setHeight(getFont().field_2000);
    }
}
