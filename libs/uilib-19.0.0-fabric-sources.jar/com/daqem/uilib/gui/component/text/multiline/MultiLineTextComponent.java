package com.daqem.uilib.gui.component.text.multiline;

import net.minecraft.class_2561;
import net.minecraft.class_332;

public class MultiLineTextComponent extends AbstractMultiLineTextComponent{

    public MultiLineTextComponent(int x, int y, int maxWidth, class_2561 text) {
        super(x, y, maxWidth, text);
    }

    public MultiLineTextComponent(int x, int y, int maxWidth, class_2561 text, int color) {
        super(x, y, maxWidth, text, color);
    }

    @Override
    public void render(class_332 guiGraphics, int mouseX, int mouseY, float partialTick, int parentWidth, int parentHeight) {
        for (int i = 0; i < getLines().size(); i++) {
            guiGraphics.method_51430(
                    getFont(),
                    getLines().get(i),
                    getTotalX(),
                    getTotalY() + i * getFont().field_2000,
                    getColor(),
                    isDrawShadow()
            );
        }

        if (isRenderDebugBorder()) {
            guiGraphics.method_51738(getTotalX() + getUnusedSpaceX(), getTotalX() + getMaxWidth() + getUnusedSpaceX() - 1, getTotalY(), 0xFF0000FF);
            guiGraphics.method_51742(getTotalX() + getMaxWidth() + getUnusedSpaceX() - 1, getTotalY(), getTotalY() + method_25364() - 1, 0xFF0000FF);
            guiGraphics.method_51738(getTotalX() + getUnusedSpaceX(), getTotalX() + getMaxWidth() + getUnusedSpaceX() - 1, getTotalY() + method_25364() - 1, 0xFF0000FF);
            guiGraphics.method_51742(getTotalX() + getUnusedSpaceX(), getTotalY(), getTotalY() + method_25364() - 1, 0xFF0000FF);
        }
    }
}
