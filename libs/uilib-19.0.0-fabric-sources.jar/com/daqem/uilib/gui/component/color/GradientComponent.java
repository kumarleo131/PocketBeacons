package com.daqem.uilib.gui.component.color;

import com.daqem.uilib.gui.component.AbstractComponent;
import net.minecraft.class_332;

public class GradientComponent extends AbstractComponent {

    private final int colorFrom;
    private final int colorTo;

    public GradientComponent(int x, int y, int width, int height, int colorFrom, int colorTo) {
        super(x, y, width, height);
        this.colorFrom = colorFrom;
        this.colorTo = colorTo;
    }

    @Override
    public void render(class_332 guiGraphics, int mouseX, int mouseY, float partialTick, int parentWidth, int parentHeight) {
        guiGraphics.method_25296(
                getTotalX(),
                getTotalY(),
                getTotalX() + method_25368(),
                getTotalY() + method_25364(),
                colorFrom,
                colorTo
        );
    }
}
