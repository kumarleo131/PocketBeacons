package com.daqem.uilib.gui.component.color;

import com.daqem.uilib.gui.component.AbstractComponent;
import net.minecraft.class_332;

public class ColorComponent extends AbstractComponent {

    private final int color;

    public ColorComponent(int x, int y, int width, int height, int color) {
        super(x, y, width, height);
        this.color = color;
    }

    @Override
    public void render(class_332 guiGraphics, int mouseX, int mouseY, float partialTick, int parentWidth, int parentHeight) {
        guiGraphics.method_25294(
                this.getTotalX(),
                this.getTotalY(),
                this.getTotalX() + this.method_25368(),
                this.getTotalY() + this.method_25364(),
                color
        );
    }
}
