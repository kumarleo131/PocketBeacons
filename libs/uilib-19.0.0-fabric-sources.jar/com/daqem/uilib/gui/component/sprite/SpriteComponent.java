package com.daqem.uilib.gui.component.sprite;

import net.minecraft.class_2960;

public class SpriteComponent extends AbstractSpriteComponent {

    public SpriteComponent(int x, int y, int width, int height, class_2960 spriteLocation) {
        super(x, y, width, height, spriteLocation);
    }
}
