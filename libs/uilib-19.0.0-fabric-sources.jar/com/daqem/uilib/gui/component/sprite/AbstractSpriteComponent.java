package com.daqem.uilib.gui.component.sprite;

import com.daqem.uilib.gui.component.AbstractComponent;
import net.minecraft.class_10799;
import net.minecraft.class_2960;
import net.minecraft.class_332;

public abstract class AbstractSpriteComponent extends AbstractComponent {

    private final class_2960 spriteLocation;

    public AbstractSpriteComponent(int x, int y, int width, int height, class_2960 spriteLocation) {
        super(x, y, width, height);
        this.spriteLocation = spriteLocation;
    }

    @Override
    public void render(class_332 guiGraphics, int mouseX, int mouseY, float partialTick, int parentWidth, int parentHeight) {
        guiGraphics.method_52706(
                class_10799.field_56883,
                spriteLocation,
                getTotalX(),
                getTotalY(),
                method_25368(),
                method_25364()
        );
    }
}
