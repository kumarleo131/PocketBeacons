package com.daqem.uilib.gui.widget;

import com.daqem.uilib.UILib;
import com.daqem.uilib.api.widget.IInputValidatable;
import com.daqem.uilib.api.widget.IWidget;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_10799;
import net.minecraft.class_2477;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_7529;
import net.minecraft.class_7999;
import net.minecraft.class_8000;
import net.minecraft.class_8030;
import net.minecraft.class_8092;

public class MultiLineEditBoxWidget extends class_7529 implements IWidget, IInputValidatable {

    private List<class_2561> inputValidationErrors = new ArrayList<>();

    public MultiLineEditBoxWidget(
            class_327 font,
            int x,
            int y,
            int width,
            int height,
            class_2561 placeholder,
            class_2561 title,
            int textColor,
            boolean textShadow,
            int cursorColor,
            boolean showBackground,
            boolean showDecorations
    ) {
        super(font, x, y, width, height, placeholder, title, textColor, textShadow, cursorColor, showBackground, showDecorations);
    }

    public MultiLineEditBoxWidget(
            class_327 font,
            int x,
            int y,
            int width,
            int height,
            class_2561 placeholder,
            class_2561 title,
            boolean showBackground,
            boolean showDecorations
    ) {
        super(font, x, y, width, height, placeholder, title, 0xFFE0E0E0, false, 0xFFD0D0D0, showBackground, showDecorations);
    }

    public MultiLineEditBoxWidget(
            class_327 font,
            int x,
            int y,
            int width,
            int height,
            class_2561 placeholder,
            class_2561 title,
            int textColor,
            boolean textShadow,
            int cursorColor
    ) {
        super(font, x, y, width, height, placeholder, title, textColor, textShadow, cursorColor, true, true);
    }

    public MultiLineEditBoxWidget(
            class_327 font,
            int x,
            int y,
            int width,
            int height,
            class_2561 placeholder,
            class_2561 title
    ) {
        super(font, x, y, width, height, placeholder, title, 0xFFE0E0E0, false, 0xFFD0D0D0, true, true);
    }

    public MultiLineEditBoxWidget(
            class_2561 placeholder,
            class_2561 title
    ) {
        super(class_310.method_1551().field_1772, 0, 0, 200, 50, placeholder, title, 0xFFE0E0E0, false, 0xFFD0D0D0, true, true);
    }

    @Override
    public void method_48579(@NotNull class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.method_48579(guiGraphics, mouseX, mouseY, partialTick);

        List<class_2561> components = this.validateInput(method_44405());
        if (components != null && !components.isEmpty()) {
            setInputValidationErrors(components);
        } else {
            clearInputValidationErrors();
        }

        List<class_2561> tooltip = getInputValidationErrorsTooltip();
        class_310 minecraft = class_310.method_1551();
        if (tooltip != null && (method_49606() || method_25370() && minecraft.method_48186().method_48183())) {
            guiGraphics.method_51436(
                    minecraft.field_1772,
                    class_2477.method_10517().method_30933(new ArrayList<>(tooltip)),
                    this.createTooltipPositioner(method_48202(), method_49606(), method_25370()),
                    mouseX,
                    mouseY,
                    method_25370()
            );
        }
    }

    @Override
    public List<class_2561> getInputValidationErrors() {
        if (this.inputValidationErrors == null) {
            this.inputValidationErrors = new ArrayList<>();
        }
        return this.inputValidationErrors;
    }

    @Override
    public void setInputValidationErrors(List<class_2561> errors) {
        if (errors == null) {
            errors = new ArrayList<>();
        }
        this.inputValidationErrors = errors;
    }

    @Override
    protected void method_44386(@NotNull class_332 guiGraphics) {
        if (hasInputValidationErrors()) {
            guiGraphics.method_52706(class_10799.field_56883, UILib.getId("widget/text_field_error"), method_46426(), method_46427(), method_25368(), method_25364());
        } else {
            super.method_44386(guiGraphics);
        }
    }

    private class_8000 createTooltipPositioner(class_8030 screenRectangle, boolean hovering, boolean focused) {
        return !hovering && focused && class_310.method_1551().method_48186().method_48183()
                ? new class_7999(screenRectangle)
                : new class_8092(screenRectangle);
    }
}
