package com.daqem.uilib.gui.widget;

import com.daqem.uilib.api.widget.IWidget;
import java.util.function.Function;
import java.util.function.Supplier;
import net.minecraft.class_2561;
import net.minecraft.class_5250;
import net.minecraft.class_5676;
import net.minecraft.class_7172;

public class CycleButtonWidget<T> extends class_5676<T> implements IWidget {

    public CycleButtonWidget(int i, int j, int k, int l, class_2561 component, class_2561 component2, int m, T object, Supplier<T> supplier, class_5680<T> valueListSupplier, Function<T, class_2561> function, Function<class_5676<T>, class_5250> function2, class_5678<T> onValueChange, class_7172.class_7277<T> tooltipSupplier, class_12346 displayState, class_12347<T> spriteSupplier) {
        super(i, j, k, l, component, component2, m, object, supplier, valueListSupplier, function, function2, onValueChange, tooltipSupplier, displayState, spriteSupplier);
    }

    public CycleButtonWidget(int i, int j, int k, int l, class_2561 component, class_2561 component2, int m, T object, Supplier<T> supplier, class_5680<T> valueListSupplier, Function<T, class_2561> function) {
        super(i, j, k, l, component, component2, m, object, supplier, valueListSupplier, function, class_5676::method_32611, (cycleButton, o) -> {
        }, o -> null, class_12346.field_64539, (cycleButton, object1) -> null);
    }
}
