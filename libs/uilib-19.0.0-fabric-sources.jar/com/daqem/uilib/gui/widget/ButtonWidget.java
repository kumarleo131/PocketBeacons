package com.daqem.uilib.gui.widget;

import com.daqem.uilib.api.widget.IWidget;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import org.jetbrains.annotations.NotNull;

public class ButtonWidget extends class_4185 implements IWidget {

    public ButtonWidget(class_2561 message) {
        this(0, 0, message);
    }

    public ButtonWidget(int x, int y, class_2561 message) {
        this(x, y, class_4185.field_39500, message);
    }

    public ButtonWidget(int x, int y, int width, class_2561 message) {
        this(x, y, width, class_4185.field_39501, message);
    }

    public ButtonWidget(int x, int y, int width, int height, class_2561 message) {
        this(x, y, width, height, message, button -> {
            // Default action does nothing
        });
    }

    public ButtonWidget(int x, int y, int width, int height, class_2561 message, class_4241 onPress) {
        this(x, y, width, height, message, onPress, class_4185.field_40754);
    }

    public ButtonWidget(int x, int y, int width, int height, class_2561 message, class_4241 onPress, class_7841 createNarration) {
        super(x, y, width, height, message, onPress, createNarration);
    }

    @Override
    protected void method_75752(@NotNull class_332 guiGraphics, int i, int j, float f) {
        this.method_75794(guiGraphics);
        this.method_75793(guiGraphics.method_75787(this, class_332.class_12228.field_63850));
    }
}
