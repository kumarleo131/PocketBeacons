package com.daqem.uilib.gui.widget;

import net.minecraft.class_10799;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_8666;
import net.minecraft.class_9848;
import org.jetbrains.annotations.NotNull;

public class CustomButtonWidget extends ButtonWidget {

    private final class_8666 sprites;

    public CustomButtonWidget(class_2561 message, class_8666 sprites) {
        super(message);
        this.sprites = sprites;
    }

    public CustomButtonWidget(int x, int y, class_2561 message, class_8666 sprites) {
        super(x, y, message);
        this.sprites = sprites;
    }

    public CustomButtonWidget(int x, int y, int width, class_2561 message, class_8666 sprites) {
        super(x, y, width, message);
        this.sprites = sprites;
    }

    public CustomButtonWidget(int x, int y, int width, int height, class_2561 message, class_8666 sprites) {
        super(x, y, width, height, message);
        this.sprites = sprites;
    }

    public CustomButtonWidget(int x, int y, int width, int height, class_2561 message, class_8666 sprites, class_4241 onPress) {
        super(x, y, width, height, message, onPress);
        this.sprites = sprites;
    }

    public CustomButtonWidget(int x, int y, int width, int height, class_2561 message, class_8666 sprites, class_4241 onPress, class_7841 createNarration) {
        super(x, y, width, height, message, onPress, createNarration);
        this.sprites = sprites;
    }

    @Override
    protected void method_75752(@NotNull class_332 guiGraphics, int i, int j, float f) {
        guiGraphics.method_52707(class_10799.field_56883, this.sprites.method_52729(this.field_22763, this.method_25367()), this.method_46426(), this.method_46427(), this.method_25368(), this.method_25364(), class_9848.method_61317(this.field_22765));
        this.method_75793(guiGraphics.method_75787(this, class_332.class_12228.field_63850));
    }
}
