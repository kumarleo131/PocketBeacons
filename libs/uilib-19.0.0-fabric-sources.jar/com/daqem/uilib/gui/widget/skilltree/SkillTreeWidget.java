package com.daqem.uilib.gui.widget.skilltree;

import com.daqem.uilib.api.IParent;
import com.daqem.uilib.api.component.IComponent;
import com.daqem.uilib.api.widget.IWidget;
import com.daqem.uilib.api.widget.skilltree.ISkillTreeWidget;
import com.daqem.uilib.gui.component.skilltree.SkillTreeMovingComponent;
import com.daqem.uilib.gui.widget.ScrollContainer2DWidget;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_11909;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_364;
import net.minecraft.class_6379;
import net.minecraft.class_6382;
import net.minecraft.class_8028;
import net.minecraft.class_8030;

public class SkillTreeWidget extends ScrollContainer2DWidget implements IWidget, IParent, ISkillTreeWidget {

    private boolean hasDragged; // Tracks if a drag occurred
    private double clickStartX; // X-coordinate where mouse was pressed
    private double clickStartY; // Y-coordinate where mouse was pressed
    private static final double DRAG_THRESHOLD = 2.0; // Pixels to consider a drag

    public SkillTreeWidget(int width, int height) {
        super(width, height);
    }

    @Override
    protected int method_44395() {
        return this.components.isEmpty() ? 0 : this.components.getFirst().method_25364();
    }

    @Override
    protected int contentWidth() {
        return this.components.isEmpty() ? 0 : this.components.getFirst().method_25368();
    }

    @Override
    public void addComponent(IComponent component) {
        this.components.clear();
        this.components.add(component);
    }

    @Override
    public void addComponents(List<? extends IComponent> components) {
        if (components.size() > 1) {
            throw new IllegalArgumentException("SkillTreeWidget can only hold one component.");
        }
        if (!components.isEmpty()) {
            this.addComponent(components.getFirst());
        }
    }

    @Override
    public void removeComponent(IComponent component) {
        if (!this.components.isEmpty() && this.components.getFirst() == component) {
            this.components.clear();
        }
    }

    @Override
    public void removeComponents(List<? extends IComponent> components) {
        if (!this.components.isEmpty() && components.contains(this.components.getFirst())) {
            this.components.clear();
        }
    }

    @Override
    public void clearComponents() {
        this.components.clear();
    }

    @Override
    protected void method_48579(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        if (this.components.isEmpty()) {
            return;
        }
        guiGraphics.method_44379(this.method_46426(), this.method_46427(), this.method_46426() + this.method_25368(), this.method_46427() + this.method_25364());
        IComponent component = this.components.getFirst();
        int offsetX = (int) this.horizontalScrollAmount();
        int offsetY = (int) this.method_44387();
        component.method_46421(this.method_46426() - uilib$getParentX() - offsetX);
        component.method_46419(this.method_46427() - uilib$getParentY() - offsetY);
        component.renderBase(guiGraphics, mouseX, mouseY, partialTick, this.method_25368(), this.method_25364());
        guiGraphics.method_44380();
    }

    @Override
    protected void method_44396(@NotNull class_332 guiGraphics, int mouseX, int mouseY) {
        // No scrollbars
    }

    @Override
    protected boolean method_44392() {
        return false;
    }

    @Override
    protected boolean horizontalScrollbarVisible() {
        return false;
    }

    @Override
    public boolean method_25402(@NotNull class_11909 event, boolean bl) {
        if (!this.field_22763 || !this.field_22764) {
            return false;
        }
        if (this.method_25351(event.comp_4800())) {
            this.hasDragged = false; // Reset drag state
            this.clickStartX = event.comp_4798(); // Store click start position
            this.clickStartY = event.comp_4799();
            this.method_25398(true); // Enable dragging
            return true;
        }
        return false;
    }

    @Override
    public boolean method_25403(@NotNull class_11909 event, double dragX, double dragY) {
        if (this.method_25351(event.comp_4800()) && this.method_25397()) {
            // Check if movement exceeds drag threshold
            double deltaX = Math.abs(event.comp_4798() - this.clickStartX);
            double deltaY = Math.abs(event.comp_4799() - this.clickStartY);
            if (deltaX > DRAG_THRESHOLD || deltaY > DRAG_THRESHOLD) {
                this.hasDragged = true;
            }
            double newHorizontal = this.horizontalScrollAmount() - dragX;
            this.setHorizontalScrollAmount(newHorizontal);
            double newVertical = this.method_44387() - dragY;
            this.method_44382(newVertical);
            return true;
        }
        return false;
    }

    @Override
    public boolean method_25406(class_11909 event) {
        super.method_25406(event);
        if (this.method_25351(event.comp_4800())) {
            this.method_25398(false);
            if (!this.hasDragged) {
                // Only process click if no drag occurred
                Optional<class_364> optional = this.method_19355(event.comp_4798(), event.comp_4799());
                if (optional.isPresent()) {
                    class_364 guiEventListener = optional.get();
                    boolean handled = guiEventListener.method_25402(event, false);
                    if (handled) {
                        this.method_25395(guiEventListener);
                        return true;
                    }
                }
                this.method_25348(event, false);
                return true;
            }
            if (this.method_25399() != null) {
                return this.method_25399().method_25406(event);
            }
        }
        return false;
    }

    @Override
    protected void method_47399(@NotNull class_6382 narrationElementOutput) {
        // No narration for skill tree widget
    }

    @Override
    public @NotNull class_8030 method_65515(@NotNull class_8028 direction) {
        return new class_8030(this.method_46426(), this.method_46427(), this.contentWidth(), this.method_44395());
    }

    @Override
    public void method_25395(@Nullable class_364 focused) {
        super.method_25395(focused);
        if (focused != null && class_310.method_1551().method_48186().method_48183()) {
            class_8030 screenRectangle = this.method_48202();
            class_8030 screenRectangle2 = focused.method_48202();
            int i = screenRectangle2.method_49618() - screenRectangle.method_49618();
            int j = screenRectangle2.method_49619() - screenRectangle.method_49619();
            if (i < 0) {
                this.method_44382(this.method_44387() + i - 14.0);
            } else if (j > 0) {
                this.method_44382(this.method_44387() + j + 14.0);
            }
        }
    }

    @Override
    public @NotNull List<? extends class_364> method_25396() {
        return this.components.isEmpty() ? List.of() : this.components.getFirst().getAllWidgets();
    }

    @Override
    public @NotNull Collection<? extends class_6379> method_65516() {
        return this.components.isEmpty() ? List.of() : this.components.getFirst().getAllWidgets();
    }

    @Override
    public List<IComponent> getComponents() {
        return new ArrayList<>(this.components);
    }

    @Override
    public void clear() {
        this.clearComponents();
    }

    @Override
    public List<IWidget> getWidgets() {
        return this.components.isEmpty() ? List.of() : this.components.getFirst().getAllWidgets();
    }

    @Override
    public void addWidget(IWidget widget) {
        throw new UnsupportedOperationException("Cannot add a widget directly to SkillTreeWidget. Add it to the component instead.");
    }

    @Override
    public void addWidgets(List<? extends IWidget> widgets) {
        throw new UnsupportedOperationException("Cannot add widgets directly to SkillTreeWidget. Add them to the component instead.");
    }

    @Override
    public void removeWidget(IWidget widget) {
        throw new UnsupportedOperationException("Cannot remove a widget directly from SkillTreeWidget. Remove it from the component instead.");
    }

    @Override
    public void removeWidgets(List<? extends IWidget> widgets) {
        throw new UnsupportedOperationException("Cannot remove widgets directly from SkillTreeWidget. Remove them from the component instead.");
    }

    @Override
    public void clearOnlyWidgets() {
        throw new UnsupportedOperationException("Cannot clear widgets directly from SkillTreeWidget. Clear them from the component instead.");
    }

    public int getContentSpacing() {
        return 0;
    }

    @Override
    public void renderTooltips(class_332 guiGraphics, int mouseX, int mouseY) {
        if (this.method_25405(mouseX, mouseY)) {
            if (!this.components.isEmpty()) {
                if (this.components.getFirst() instanceof SkillTreeMovingComponent skillTreeMovingComponent) {
                    skillTreeMovingComponent.renderTooltips(guiGraphics, mouseX, mouseY);
                }
            }
        }
    }
}