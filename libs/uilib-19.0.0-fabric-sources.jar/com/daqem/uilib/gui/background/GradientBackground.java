package com.daqem.uilib.gui.background;

import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;

public class GradientBackground extends AbstractBackground {

    private int colorFrom;
    private int colorTo;

    public GradientBackground(int colorFrom, int colorTo) {
        this.colorFrom = colorFrom;
        this.colorTo = colorTo;
    }

    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        if (class_310.method_1551().field_1755 instanceof class_437 screen) {
            guiGraphics.method_25296(0, 0, screen.field_22789, screen.field_22790, colorFrom, colorTo);
        }
    }

    public int getColorFrom() {
        return colorFrom;
    }

    public void setColorFrom(int colorFrom) {
        this.colorFrom = colorFrom;
    }

    public int getColorTo() {
        return colorTo;
    }

    public void setColorTo(int colorTo) {
        this.colorTo = colorTo;
    }
}
