package com.daqem.uilib.gui.background;

import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;

public class ColorBackground extends AbstractBackground {

    private int color;

    public ColorBackground(int color) {
        this.color = color;
    }

    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        if (class_310.method_1551().field_1755 instanceof class_437 screen) {
            guiGraphics.method_25294(0, 0, screen.field_22789, screen.field_22790, color);
        }
    }

    public int getColor() {
        return color;
    }

    public void setColor(int color) {
        this.color = color;
    }
}
