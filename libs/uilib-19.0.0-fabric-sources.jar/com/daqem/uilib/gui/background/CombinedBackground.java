package com.daqem.uilib.gui.background;

import com.daqem.uilib.api.background.IBackground;
import net.minecraft.class_332;

public class CombinedBackground extends AbstractBackground {

    private final IBackground[] backgrounds;

    public CombinedBackground(IBackground... backgrounds) {
        this.backgrounds = backgrounds;
    }

    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        for (IBackground background : backgrounds) {
            background.method_25394(guiGraphics, mouseX, mouseY, partialTick);
        }
    }
}
