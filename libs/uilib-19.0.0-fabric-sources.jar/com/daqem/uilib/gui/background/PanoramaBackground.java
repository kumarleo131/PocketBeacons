package com.daqem.uilib.gui.background;

import com.daqem.uilib.api.screen.IScreenAccessor;
import net.minecraft.class_310;
import net.minecraft.class_332;

public class PanoramaBackground extends  AbstractBackground {

    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        if (class_310.method_1551().field_1755 instanceof IScreenAccessor screen) {
            screen.uilib$renderPanoramaBackground(guiGraphics, partialTick);
        }
    }
}
