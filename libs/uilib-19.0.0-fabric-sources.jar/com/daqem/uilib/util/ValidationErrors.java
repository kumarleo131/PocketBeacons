package com.daqem.uilib.util;

import com.daqem.uilib.UILib;
import net.minecraft.class_5250;

public class ValidationErrors {

    public static class_5250 minLength(int length) {
        return UILib.translatable("widget.validation_error.min_length", length);
    }

    public static class_5250 maxLength(int length) {
        return UILib.translatable("widget.validation_error.max_length", length);
    }

    public static class_5250 pattern(String pattern) {
        return UILib.translatable("widget.validation_error.pattern", pattern);
    }

    public static class_5250 validValues(Object values) {
        return UILib.translatable("widget.validation_error.valid_values", values.toString());
    }

    public static class_5250 minValue(Number value) {
        return UILib.translatable("widget.validation_error.min_value", value);
    }

    public static class_5250 maxValue(Number value) {
        return UILib.translatable("widget.validation_error.max_value", value);
    }

    public static class_5250 invalidNumber() {
        return UILib.translatable("widget.validation_error.invalid_number");
    }

    public static class_5250 invalidDateTime(String format) {
        return UILib.translatable("widget.validation_error.invalid_date_time", format);
    }

    public static class_5250 invalidIdentifier() {
        return UILib.translatable("widget.validation_error.invalid_resource_location");
    }

    public static class_5250 invalidRegistryValue() {
        return UILib.translatable("widget.validation_error.invalid_registry_value");
    }

    public static class_5250 duplicateKey() {
        return UILib.translatable("widget.validation_error.duplicate_key");
    }

    public static class_5250 emptyKey() {
        return UILib.translatable("widget.validation_error.empty_key");
    }
}
